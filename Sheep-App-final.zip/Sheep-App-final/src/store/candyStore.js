export const candyStore = {
    candies: [],
    cart: []
};